import React, { useEffect, useState } from 'react';
import { QuizState, SIFCounters, FAMILY_TO_FACES } from '@/types/quiz';

interface PhaseDProps {
  state: QuizState;
  onSIFCalculate: (primaryFamily: string, primaryFace: string) => void;
  onRecordAllSIFData: (quizData: any, primaryFamily: string, primaryFace: string) => void;
  onProceedToE: () => void;
}


export default function PhaseD({ state, onSIFCalculate, onRecordAllSIFData, onProceedToE }: PhaseDProps) {
  const [autoProceed, setAutoProceed] = useState(false);
  const [hasRecorded, setHasRecorded] = useState(false);

  console.log('📊 Phase D - SIF State:', {
    sifCounters: state.sifCounters,
    sifResult: state.sifResult,
    anchor: state.anchor
  });

  // Phase D is now just a transition phase - no SIF recording until primary is finalized
  useEffect(() => {
    if (!hasRecorded) {
      console.log('🎯 PHASE D - Transitioning to Phase E for primary resolution');
      
      // Mark as recorded to prevent re-execution
      setHasRecorded(true);
      
      // Auto-proceed to Phase E for primary resolution
      setAutoProceed(true);
    }
  }, [hasRecorded]);

  // Auto-proceed after data recording is complete
  useEffect(() => {
    if (autoProceed) {
      console.log('🎯 Auto-proceeding to Phase E in 2 seconds...');
      
      const timer = setTimeout(() => {
        console.log('🎯 Auto-proceeding to Phase E now');
        onProceedToE();
      }, 2000); // 2 second delay
      
      return () => clearTimeout(timer);
    }
  }, [autoProceed, onProceedToE]);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Phase D: Data Recording</h1>
          
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-blue-800 mb-4">Phase C Complete</h2>
              <div className="space-y-2 text-sm text-blue-700">
                <p><strong>Quiz Data:</strong> All responses recorded</p>
                <p><strong>Next Step:</strong> Primary family and face selection</p>
                <p><strong>Note:</strong> SIF calculation will happen after primary is finalized</p>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-gray-600 mb-4">Proceeding to Archetype selection in 2 seconds...</p>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{width: '100%'}}></div>
              </div>
              <button
                onClick={onProceedToE}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Proceed to Archetype Selection Now
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}