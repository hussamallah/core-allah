import React, { useEffect, useMemo, useState } from 'react';
import { QuizState } from '@/types/quiz';
import { ANCHOR_BLURBS } from '@/data/questions';
import { FAMILY_TO_FACES } from '@/types/quiz';

interface PhaseEProps {
  state: QuizState;
  onAnchorSelect: (anchor: string) => void;
  onAddQuestionToHistory: (phase: 'A' | 'B' | 'C' | 'D' | 'E', lineId: string, questionId: string, choice: string) => void;
}

export function PhaseE({ state, onAnchorSelect, onAddQuestionToHistory }: PhaseEProps) {
  const selectedALines = state.lines.filter(l => l.selectedA);
  const nonALines = state.lines.filter(l => !l.selectedA);
  
  // State for tie-breaking
  const [tieBreakingState, setTieBreakingState] = useState<{
    isActive: boolean;
    tiedFamilies: string[];
  }>({
    isActive: false,
    tiedFamilies: []
  });

  // Log SIF state at start of Phase E
  React.useEffect(() => {
    console.log('🎯 PHASE E - SIF State:', {
      sifCounters: state.sifCounters,
      sifResult: state.sifResult,
      selectedALines: selectedALines.map(l => l.id),
      nonALines: nonALines.map(l => l.id),
      currentAnchor: state.anchor
    });
  }, [state.sifCounters, state.sifResult, selectedALines, nonALines, state.anchor]);

  // Calculate purity according to canonical specification
  const calculatePurity = (line: any) => {
    if (line.selectedA) {
      // A-lines: use face purity (C_evidence from Phase B)
      return line.B.C_evidence;
    } else {
      // Non-A lines: use canonical purity formula
      // purity = 1.0*(CO=C) + 1.6*(CF=C) - 1.0*(CO=O) - 1.6*(CF=F)
      const decisions = line.mod.decisions;
      let purity = 0;
      
      decisions.forEach((decision: any) => {
        if (decision.type === 'CO1' || decision.type === 'CO2') {
          if (decision.pick === 'C') purity += 1.0;
          else if (decision.pick === 'O') purity -= 1.0;
        } else if (decision.type === 'CF') {
          if (decision.pick === 'C') purity += 1.6;
          else if (decision.pick === 'F') purity -= 1.6;
        }
      });
      
      return purity;
    }
  };

  const candidates = useMemo(() => {
    let result: string[] = [];
    
    // Calculate purity for all lines using canonical formula
    const allPurity: Record<string, number> = {};
    state.lines.forEach(line => {
      allPurity[line.id] = calculatePurity(line);
    });
    
    console.log('🔍 All purity scores:', allPurity);
    
    // Priority 1: Any A-line with exactly 2.6
    const a26 = selectedALines.filter(l => Math.abs(allPurity[l.id] - 2.6) < 1e-9);
    if (a26.length) {
      result = a26.map(l => l.id);
      console.log('🎯 Priority 1 - A-lines with 2.6:', result);
    } else {
      // Priority 2: Any line with exactly 3.0
      const anyThree = state.lines.filter(l => Math.abs(allPurity[l.id] - 3.0) < 1e-9);
      if (anyThree.length) {
        result = anyThree.map(l => l.id);
        console.log('🎯 Priority 2 - Lines with 3.0:', result);
      } else {
        // Priority 3: Best score less than 3.0 (higher is better)
        let best = -999;
        let names: string[] = [];
        state.lines.forEach(l => {
          const p = allPurity[l.id];
          if (Math.abs(p - 2.6) < 1e-9) return; // exclude 2.6 here per rule
          if (p < 3.0 - 1e-9) {
            if (p > best + 1e-9) { 
              best = p; 
              names = [l.id]; 
            } else if (Math.abs(p - best) < 1e-9) { 
              names.push(l.id); 
            }
          }
        });
        result = names;
        console.log('🎯 Priority 3 - Best < 3.0:', result, 'best score:', best);
      }
    }
    return result;
  }, [selectedALines, state.lines]);

  // Handle candidates and tie-breaking
  useEffect(() => {
    console.log('🔍 Phase E - Candidates:', candidates);
    console.log('🔍 Phase E - Current anchor:', state.anchor);
    
    if (state.anchor) return; // Already have an anchor
    
    if (candidates.length === 1) {
      console.log('🎯 Auto-selecting anchor (single candidate):', candidates[0]);
      // For single candidate, we need to pick the face with most votes
      const family = candidates[0];
      const faces = FAMILY_TO_FACES[family] || [];
      if (faces.length > 0) {
        // Find face with most votes
        const faceVotes: Record<string, number> = {};
        faces.forEach(face => {
          const faceKey = `${family}:${face}`;
          faceVotes[face] = state.sifCounters.faceC[faceKey] || 0;
        });
        const selectedFace = Object.keys(faceVotes).reduce((a, b) => 
          faceVotes[a] >= faceVotes[b] ? a : b
        );
        const primaryFace = `${family}:${selectedFace}`;
        console.log('🎯 Auto-selected primary face:', primaryFace, 'Reason: Single candidate, face votes:', faceVotes);
        onAnchorSelect(primaryFace);
      } else {
        console.log('🎯 Auto-selected family (no faces available):', family);
        onAnchorSelect(family); // Fallback
      }
    } else if (candidates.length > 1 && !tieBreakingState.isActive) {
      console.log('🎯 Multiple candidates detected, starting tie-breaking process');
      setTieBreakingState({
        isActive: true,
        tiedFamilies: candidates
      });
    }
  }, [candidates, state.anchor, onAnchorSelect, tieBreakingState.isActive]);



  // If anchor is already selected, show brief loading screen
  if (state.anchor) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 min-h-[500px] flex items-center justify-center">
        <div className="text-center">
          <div className="text-yellow-400 text-2xl font-bold mb-4">Primary selected: {state.anchor}</div>
          <div className="text-gray-200 text-lg mb-6">Proceeding to Summary...</div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div className="bg-yellow-400 h-2 rounded-full animate-pulse" style={{width: '100%'}}></div>
          </div>
        </div>
      </div>
    );
  }

  // Show tie-breaking selection if active
  if (tieBreakingState.isActive) {
    // Ties: prefer A-lines; else user picks
    const aInTie = tieBreakingState.tiedFamilies.filter(id => state.lines.find(l => l.id === id)?.selectedA);
    let tieSet = tieBreakingState.tiedFamilies;
    let tieReason = 'User picks from all tied families';
    
    if (aInTie.length) {
      tieSet = aInTie;
      tieReason = `A-line preference: showing only A-lines (${aInTie.join(', ')}) from tied families`;
    }
    
    console.log('🎯 Tie-break setup:', {
      tiedFamilies: tieBreakingState.tiedFamilies,
      aInTie,
      tieSet,
      reason: tieReason
    });

    return (
      <div className="bg-gray-900 rounded-xl p-8 min-h-[500px]">
        <h2 className="text-2xl font-bold text-white mb-6">Phase E — Primary Selection</h2>
        <p className="text-ivory text-xl mb-8 font-medium">Pick one family + face for your primary:</p>
        
        <div className="space-y-6">
          {tieSet.map(family => (
            <div key={family} className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold text-white mb-4">{family}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {FAMILY_TO_FACES[family]?.map(face => (
                  <button
                    key={`${family}:${face}`}
                    onClick={() => {
                      const primaryFace = `${family}:${face}`;
                      console.log('🎯 Tie-break selection:', {
                        tiedFamilies: tieBreakingState.tiedFamilies,
                        selectedFamily: family,
                        selectedFace: face,
                        primaryFace,
                        reason: 'User selected from tied families'
                      });
                      onAnchorSelect(primaryFace); // Pass full primary face
                      onAddQuestionToHistory('E', family, `primary-${family}-${face}`, 'selected');
                    }}
                    className="p-4 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-all duration-300 hover:border-yellow-400 hover:shadow-lg hover:shadow-yellow-400/10"
                  >
                    <div className="font-bold text-ivory text-lg mb-2">{family}:{face}</div>
                    <div className="text-gray-400 text-sm">Primary choice</div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Fallback: should not reach here in normal flow
  return (
    <div className="bg-gray-900 rounded-xl p-8 min-h-[500px] flex items-center justify-center">
      <div className="text-center">
        <div className="text-yellow-400 text-2xl font-bold mb-4">Processing...</div>
        <div className="text-gray-200 text-lg">Determining anchor selection</div>
      </div>
    </div>
  );
}