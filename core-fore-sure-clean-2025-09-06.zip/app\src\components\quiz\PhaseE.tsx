import React, { useEffect, useState } from 'react';
import { QuizState } from '@/types/quiz';
import { phaseEEngine, LineResult } from '@/engine/PhaseE';

type Family = 'Control' | 'Pace' | 'Boundary' | 'Truth' | 'Recognition' | 'Bonding' | 'Stress';

interface PhaseEProps {
  state: QuizState;
  onAddQuestionToHistory: (phase: 'A' | 'B' | 'C' | 'D' | 'E', lineId: string, questionId: string, choice: string) => void;
  onProceedToArchetype?: (payload: {
    selectedLine: Family;
    anchorSource: "E:Purity" | "E:TieBreak";
  }) => void;
}

type PhaseEStatus = 'IDLE' | 'PROCESSING' | 'COMMITTED';

export function PhaseE({ state, onAddQuestionToHistory, onProceedToArchetype }: PhaseEProps) {
  const [phaseEState, setPhaseEState] = useState(phaseEEngine.getState());
  const [hasEntered, setHasEntered] = useState(false);
  const [status, setStatus] = useState<PhaseEStatus>('IDLE');

  // Safe default with noop guard to prevent type errors during HMR
  const proceed = onProceedToArchetype ?? (() => {
    console.warn("[PhaseE] onProceedToArchetype missing; no-op");
  });

  // Calculate purity for all lines
  const calculatePurity = (line: any) => {
    if (line.selectedA) {
      // A-lines: use face purity (C_evidence from Phase B)
      return line.B.C_evidence;
    } else {
      // Non-A lines: use canonical purity formula
      // purity = 1.0*(CO=C) + 1.6*(CF=C) - 1.0*(CO=O) - 1.6*(CF=F)
      const decisions = line.mod.decisions;
      let purity = 0;
      
      decisions.forEach((decision: any) => {
        if (decision.type === 'CO1' || decision.type === 'CO2') {
          if (decision.pick === 'C') purity += 1.0;
          else if (decision.pick === 'O') purity -= 1.0;
        } else if (decision.type === 'CF') {
          if (decision.pick === 'C') purity += 1.6;
          else if (decision.pick === 'F') purity -= 1.6;
        }
      });
      
      return purity;
    }
  };

  // Convert lines to LineResult format
  const lineResults: LineResult[] = state.lines.map(line => ({
    line: line.id,
    isALine: line.selectedA,
    facePurity: line.selectedA ? line.B.C_evidence : 0,
    modulePurity: line.selectedA ? 0 : calculatePurity(line)
  }));

  // Enter Phase E once
  useEffect(() => {
    if (!hasEntered) {
      console.log('🎯 PHASE E - Entering Phase E');
      const newState = phaseEEngine.enterPhaseE(lineResults);
      setPhaseEState(newState);
      setHasEntered(true);

      // Auto-select if single candidate - go to Summary phase
      if (newState.anchor && status === 'IDLE') {
        console.log('🎯 PHASE E - Auto-selecting anchor:', newState.anchor);
        setStatus('COMMITTED');
        proceed({ 
          selectedLine: newState.anchor as Family, 
          anchorSource: "E:Purity" 
        });
      }
    }
  }, [hasEntered, lineResults, proceed, status]);

  // Handle tie-break selection
  const handleTieBreakSelection = (selectedLine: string) => {
    if (status !== 'IDLE') {
      console.warn("[PhaseE] Already committed, ignoring selection");
      return;
    }

    console.log('🎯 PHASE E - Tie-break selection:', selectedLine);
    setStatus('PROCESSING');
    
    phaseEEngine.selectAnchor(selectedLine);
    const newState = phaseEEngine.getState();
    setPhaseEState(newState);
    
    // Record in question history
    onAddQuestionToHistory('E', selectedLine, 'tie-break-question', 'selected');
    
    // Go to Summary phase
    setStatus('COMMITTED');
    proceed({ 
      selectedLine: selectedLine as Family, 
      anchorSource: "E:TieBreak" 
    });

    // Debug helper for development
    if (typeof window !== 'undefined') {
      (window as any).__lastPhaseE = { 
        candidates: phaseEState.candidates, 
        selectedLine, 
        at: Date.now() 
      };
    }
  };

  // Prize role mapping
  const PRIZE_ROLES: Record<string, string> = {
    'Control': 'Authority',
    'Pace': 'Timekeeper', 
    'Boundary': 'Gatekeeper',
    'Truth': 'Decider',
    'Recognition': 'Witness',
    'Bonding': 'Anchor',
    'Stress': 'Igniter'
  };

  // If anchor already selected, show loading
  if (phaseEState.anchor) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 min-h-[500px] flex items-center justify-center">
        <div className="text-center">
          <div className="text-yellow-400 text-2xl font-bold mb-4">Primary selected: {phaseEState.anchor}</div>
          <div className="text-gray-200 text-lg mb-6">Proceeding to Summary...</div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div className="bg-yellow-400 h-2 rounded-full animate-pulse" style={{width: '100%'}}></div>
          </div>
        </div>
      </div>
    );
  }

  // Show tie-break question if needed
  if (phaseEEngine.needsTieBreak()) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 min-h-[500px]">
        <h2 className="text-2xl font-bold text-white mb-6">Phase E — Primary Selection</h2>
        <p className="text-ivory text-xl mb-8 font-medium">
          When it actually lands on you, which line do you trust to carry your week?
        </p>
        
        <div className="space-y-4">
          {phaseEState.candidates.map(line => (
            <button
              key={line}
              onClick={() => handleTieBreakSelection(line)}
              disabled={status !== 'IDLE'}
              className={`w-full p-6 border rounded-lg transition-all duration-300 text-left ${
                status === 'IDLE' 
                  ? 'bg-gray-800 border-gray-600 hover:bg-gray-700 hover:border-yellow-400 hover:shadow-lg hover:shadow-yellow-400/10' 
                  : 'bg-gray-900 border-gray-700 cursor-not-allowed opacity-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-ivory text-xl mb-2">{line}</div>
                  <div className="text-gray-400 text-sm">
                    {line === 'Control' && 'Set the call · Authority'}
                    {line === 'Pace' && 'Keep the tempo · Timekeeper'}
                    {line === 'Boundary' && 'Hold the line · Gatekeeper'}
                    {line === 'Truth' && 'Land the call · Decider'}
                    {line === 'Recognition' && 'Make it visible · Witness'}
                    {line === 'Bonding' && 'Steady the bond · Anchor'}
                    {line === 'Stress' && 'Spark the motion · Igniter'}
                  </div>
                </div>
                <div className="text-yellow-400 text-sm font-semibold">Lock Anchor</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Fallback: should not reach here
  return (
    <div className="bg-gray-900 rounded-xl p-8 min-h-[500px] flex items-center justify-center">
      <div className="text-center">
        <div className="text-yellow-400 text-2xl font-bold mb-4">Processing...</div>
        <div className="text-gray-200 text-lg">Determining anchor selection</div>
      </div>
    </div>
  );
}