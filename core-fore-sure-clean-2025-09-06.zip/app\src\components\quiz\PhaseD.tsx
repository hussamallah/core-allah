import React, { useEffect, useState, useRef } from 'react';
import { QuizState } from '@/types/quiz';
import { phaseDEngine } from '@/engine/PhaseD';
import { quizRecorder } from '@/utils/QuizRecorder';

interface PhaseDProps {
  state: QuizState;
  onSIFCalculate: (primaryFamily: string, primaryFace: string, prizeFace?: string) => any;
  onRecordAllSIFData: (quizData: any, primaryFamily: string, primaryFace: string) => void;
  onProceedToE: () => void;
}

export default function PhaseD({ state, onSIFCalculate, onRecordAllSIFData, onProceedToE }: PhaseDProps) {
  const [hasComputed, setHasComputed] = useState(false);
  const didCommit = useRef(false);
  const proceedTimer = useRef<NodeJS.Timeout | null>(null);

  // Phase D: Compute-only with deterministic verdict table
  useEffect(() => {
    if (didCommit.current) {
      console.log('🎯 PHASE D - Already committed, skipping');
      return;
    }

    console.log('🎯 PHASE D - Computing verdicts with deterministic table');
    console.log('🎯 PHASE D - State lines:', state.lines.map(l => ({ id: l.id, selectedA: l.selectedA, picks: l.B?.picks, decisions: l.mod?.decisions })));
    
    const verdicts = phaseDEngine.computeVerdicts(state.lines);
    console.log('🎯 PHASE D - Verdicts computed:', verdicts);
    
    // Record each verdict to the QuizRecorder
    verdicts.forEach(verdict => {
      quizRecorder.recordVerdictCalculation(verdict.lineId, verdict.verdict, []);
    });
    
    // Record Phase D completion
    quizRecorder.record({
      phase: 'D',
      action: 'verdict_calculated',
      details: { 
        totalVerdicts: verdicts.length,
        verdicts: verdicts.map(v => ({ lineId: v.lineId, verdict: v.verdict }))
      }
    });
    
    console.log('🎯 PHASE D - Verdicts recorded to QuizRecorder');
    
    setHasComputed(true);
    didCommit.current = true;
    
    // Auto-proceed to Phase E after computation
    proceedTimer.current = setTimeout(() => {
      console.log('🎯 PHASE D - Proceeding to Phase E');
      onProceedToE();
    }, 1000);
    
    return () => {
      if (proceedTimer.current) {
        clearTimeout(proceedTimer.current);
      }
    };
  }, []); // Empty dependency array - only run once on mount

  // Fallback: if we've computed but haven't proceeded after 3 seconds, force proceed
  useEffect(() => {
    if (hasComputed) {
      const fallbackTimer = setTimeout(() => {
        console.log('🎯 PHASE D - Fallback: Force proceeding to Phase E');
        onProceedToE();
      }, 3000);
      
      return () => clearTimeout(fallbackTimer);
    }
  }, [hasComputed, onProceedToE]);

  return (
    <div className="bg-gray-900 rounded-xl p-8 min-h-[500px] flex items-center justify-center">
      <div className="text-center">
        <div className="text-yellow-400 text-2xl font-bold mb-4">Phase D — Computing Verdicts</div>
        <div className="text-gray-200 text-lg mb-6">Using deterministic verdict table...</div>
        <div className="w-full bg-gray-700 rounded-full h-2 mb-6">
          <div className="bg-yellow-400 h-2 rounded-full animate-pulse" style={{width: '100%'}}></div>
        </div>
        
        {hasComputed && (
          <div className="mt-4">
            <div className="text-green-400 text-sm mb-2">✅ Verdicts computed successfully</div>
            <button
              onClick={() => {
                console.log('🎯 PHASE D - Manual proceed to Phase E');
                onProceedToE();
              }}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
            >
              Proceed to Phase E
            </button>
          </div>
        )}
      </div>
    </div>
  );
}