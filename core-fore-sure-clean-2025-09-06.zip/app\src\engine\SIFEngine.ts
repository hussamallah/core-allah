/**
 * SIF (Secondary Identity Face) Engine
 * 
 * Handles counting signals during quiz phases and calculating SIF in Phase D
 * Follows the SIF specification: count during run, decide at Phase D
 */

import { SIFCounters, SIFResult, FACE_TO_FAMILY, FAMILY_TO_FACES, FAMILY_TO_PRIZE, PRIZE_MIRROR_MAP, getPrizeMirror } from '@/types/quiz';

export class SIFEngine {
  private counters: SIFCounters;
  private didRecordAll: boolean = false;
  private didRecordPhaseD: boolean = false;
  private snapshot: any = null;
  private opportunities: Record<string, number> = {}; // Track opportunities per face

  constructor() {
    this.counters = {
      famC: {},
      famO: {},
      famF: {},
      sevF: {},
      faceC: {},
      faceO: {}
    };
  }

  // Helper to safely increment counters
  private inc(obj: Record<string, number>, key: string, by = 1): void {
    obj[key] = (typeof obj[key] === "number" ? obj[key] : 0) + by;
  }

  /**
   * Initialize counters for all families and faces
   */
  initializeCounters(): void {
    const families = ['Control', 'Pace', 'Boundary', 'Truth', 'Recognition', 'Bonding', 'Stress'];
    const faces = Object.keys(FACE_TO_FAMILY);

    families.forEach(family => {
      this.counters.famC[family] = 0;
      this.counters.famO[family] = 0;
      this.counters.famF[family] = 0;
      this.counters.sevF[family] = 0;
    });

    faces.forEach(face => {
      this.counters.faceC[face] = 0;
      this.counters.faceO[face] = 0;
    });
  }

  /**
   * Record answer during Phase B (duels)
   */
  recordPhaseBAnswer(family: string, questionType: 'CO' | 'CF', choice: 'A' | 'B'): void {
    console.log(`📊 SIF Phase B: ${family} ${questionType} choice ${choice}`);
    
    if (questionType === 'CO') {
      if (choice === 'A') {
        this.inc(this.counters.famC, family);
        console.log(`  → famC[${family}] = ${this.counters.famC[family]}`);
      } else {
        this.inc(this.counters.famO, family);
        console.log(`  → famO[${family}] = ${this.counters.famO[family]}`);
      }
    } else if (questionType === 'CF') {
      if (choice === 'A') {
        this.inc(this.counters.famC, family);
        console.log(`  → famC[${family}] = ${this.counters.famC[family]}`);
      } else {
        this.inc(this.counters.famF, family);
        console.log(`  → famF[${family}] = ${this.counters.famF[family]}`);
      }
    }
    
    console.log('📊 SIF Counters after Phase B:', this.counters);
  }

  /**
   * Record answer during Phase C (fused items)
   * Records both family and face counters for the anchored face
   */
  recordPhaseCAnswer(family: string, questionType: 'CO' | 'CF', choice: 'A' | 'B', anchoredFace: string): void {
    console.log(`📊 SIF Phase C: ${family} ${questionType} choice ${choice} anchoredFace ${anchoredFace}`);
    
    // Handle CF/B case - only famF, no face vote
    if (questionType === 'CF' && choice === 'B') {
      this.inc(this.counters.famF, family);
      console.log(`  → famF[${family}] = ${this.counters.famF[family]}`);
      console.log(`  → no face vote for CF/B`);
      return;
    }
    
    // Handle C/O family signal
    if (choice === 'A') {
      this.inc(this.counters.famC, family);
      console.log(`  → famC[${family}] = ${this.counters.famC[family]}`);
    } else {
      this.inc(this.counters.famO, family);
      console.log(`  → famO[${family}] = ${this.counters.famO[family]}`);
    }
    
    // Track opportunities (all anchored faces get a chance to be voted on)
    this.inc(this.opportunities, anchoredFace);
    
    // Face vote only on positive endorsements (choice === 'A')
    // CO: choice 'A' = faceC++, choice 'B' = faceO++
    // CF: choice 'A' = faceC++, choice 'B' = no face vote (by design)
    if (choice === 'A') {
      this.inc(this.counters.faceC, anchoredFace);
      console.log(`  → faceC[${anchoredFace}] = ${this.counters.faceC[anchoredFace]} (positive endorsement)`);
    } else if (questionType === 'CO') {
      // Only CO questions get faceO votes on choice 'B'
      this.inc(this.counters.faceO, anchoredFace);
      console.log(`  → faceO[${anchoredFace}] = ${this.counters.faceO[anchoredFace]} (negative endorsement)`);
    } else {
      // CF questions with choice 'B' get no face vote (by design)
      console.log(`  → no face vote for ${questionType}/B (by design)`);
    }
    
    console.log('📊 SIF Counters after Phase C:', this.counters);
  }

  /**
   * Record all SIF data from quiz results
   * FIXED: This is now a snapshot-only method, no double counting
   */
  recordAllSIFData(quizData: any, primaryFamily: string, primaryFace: string): void {
    if (this.didRecordAll) {
      console.log('📊 SIF Recording All Data: Already recorded, skipping');
      return;
    }
    
    this.didRecordAll = true;
    console.log('📊 SIF Recording All Data: Snapshot only (counters already live)', { 
      primaryFamily, 
      primaryFace,
      currentCounters: this.counters 
    });
    
    // DO NOT replay picks into counters - they're already live from Phase B/C
    // Just store the data for reference
    this.snapshot = { primaryFamily, primaryFace, quizData };
  }

  /**
   * Record severity probe result
   */
  recordSeverityProbe(family: string, severity: 'F0' | 'F0.5' | 'F1'): void {
    this.counters.sevF[family]++;
    console.log(`📊 SIF Severity Probe: ${family} severity ${severity} → sevF[${family}] = ${this.counters.sevF[family]}`);
    console.log('📊 SIF Counters after Severity Probe:', this.counters);
  }

  /**
   * Calculate SIF result in Phase D
   * CORRECTED: Uses archetype-level scoring, excludes F-verdict families, proper tie-breaking
   */
  calculateSIF(primaryFamily: string, primaryFace: string, familyVerdicts: Record<string, "C" | "O" | "F">, prizeFace?: string): SIFResult {
    // Determine prize face using Prize Mirror mapping
    const prizeMirror = getPrizeMirror(primaryFace);
    const actualPrizeFace = prizeFace || prizeMirror || FAMILY_TO_PRIZE[primaryFamily] || primaryFace;
    
    console.log('🎯 SIF CALCULATION START:', {
      primaryFamily,
      primaryFace,
      prizeFace: actualPrizeFace,
      prizeMirror: getPrizeMirror(primaryFace),
      familyVerdicts,
      counters: this.counters
    });

    // Defensive prize calculation: derive family verdicts if empty
    let effectiveFamilyVerdicts = familyVerdicts;
    if (Object.keys(familyVerdicts).length === 0) {
      console.warn('⚠️ Empty familyVerdicts - deriving from SIF counters as fallback');
      
      // Derive family verdicts from SIF counters
      // If a family has famF > 0, it's F; otherwise if famC > famO, it's C; else O
      effectiveFamilyVerdicts = {};
      const allFamilies = ['Control', 'Pace', 'Boundary', 'Truth', 'Recognition', 'Bonding', 'Stress'];
      
      allFamilies.forEach(family => {
        const famC = this.counters.famC[family] || 0;
        const famO = this.counters.famO[family] || 0;
        const famF = this.counters.famF[family] || 0;
        
        if (famF > 0) {
          effectiveFamilyVerdicts[family] = 'F';
        } else if (famC > famO) {
          effectiveFamilyVerdicts[family] = 'C';
        } else if (famO > famC) {
          effectiveFamilyVerdicts[family] = 'O';
        } else {
          // No data - default to O (neutral)
          effectiveFamilyVerdicts[family] = 'O';
        }
      });
      
      console.log('🎯 Derived family verdicts from SIF counters:', effectiveFamilyVerdicts);
    }

    // Get all faces with their families
    const allFaces = Object.keys(FACE_TO_FAMILY).map(face => ({
      face,
      family: FACE_TO_FAMILY[face]
    }));

    // Filter candidates: exclude entire primary family and F-verdict families
    const primaryFamilyFromFace = primaryFace.split(':')[0]; // Extract family from "Family:Face"
    const candidatePool = allFaces.filter(({ face, family }) => {
      const isNotPrimaryFamily = family !== primaryFamilyFromFace;
      const familyNotF = effectiveFamilyVerdicts[family] !== 'F';
      return isNotPrimaryFamily && familyNotF;
    });
    
    console.log('🎯 SIF Candidate Pool (after exclusions):', {
      primaryFace,
      excludedFaces: allFaces.filter(({ face, family }) => face === primaryFace.split(':')[1] || effectiveFamilyVerdicts[family] === 'F'),
      candidatePool
    });

    // Log the face counters and opportunities for debugging
    console.debug('SIFEngine faceC counters:', this.counters.faceC);
    console.debug('SIFEngine faceO counters:', this.counters.faceO);
    console.debug('SIFEngine opportunities:', this.opportunities);
    
    // Score each candidate face using the correct formula
    const scoredCandidates = candidatePool.map(({ face, family }) => {
      const faceKey = `${family}:${face}`;  // e.g. "Control:Rebel"
      const pos = this.counters.faceC?.[faceKey] ?? 0;  // direct "fits me" votes
      const neg = this.counters.faceO?.[faceKey] ?? 0;  // "not me" votes
      const opportunities = this.opportunities[faceKey] ?? 0;  // total opportunities
      const rawNI = Math.max(0, pos - neg);  // or just `pos` if that's the spec
      
      // Calculate rates for transparency
      const positiveRate = opportunities > 0 ? (pos / opportunities).toFixed(3) : '0.000';
      const negativeRate = opportunities > 0 ? (neg / opportunities).toFixed(3) : '0.000';
      const famC = this.counters.famC[family] || 0;
      const famO = this.counters.famO[family] || 0;
      const famF = this.counters.famF[family] || 0;
      const sevF = this.counters.sevF[family] || 0;
      
      const hasExposure = (famC + famO) > 0;
      const SI = hasExposure ? famC / (famC + famO) : 0.5;  // Family stability, neutral if no answers
      console.debug(`SI for ${family}: ${SI.toFixed(3)} ${hasExposure ? '' : '(neutral fallback)'}`);
      const II = Math.min(famF + sevF, 3);  // Instability, capped at 3
      
      return {
        face,
        family,
        rawNI,
        SI,
        II,
        famC,
        famO
      };
    });

    // Normalize after computing rawNI for all candidates
    const maxNI = Math.max(0, ...scoredCandidates.map(c => c.rawNI));
    const finalCandidates = scoredCandidates.map(c => {
      const NI = maxNI > 0 ? c.rawNI / maxNI : 0;
      const faceScore = 0.5 * NI + 0.5 * c.SI - 0.1 * c.II;
      
      return {
        face: c.face,
        family: c.family,
        score: faceScore,
        NI,
        SI: c.SI,
        II: c.II,
        rawNI: c.rawNI
      };
    });

    // Log all face scores with rates for debugging
    console.log('🎯 SIF Face Scores (before sorting):', finalCandidates.map(c => {
      const faceKey = `${c.family}:${c.face}`;
      const opportunities = this.opportunities[faceKey] ?? 0;
      const pos = this.counters.faceC[faceKey] ?? 0;
      const neg = this.counters.faceO[faceKey] ?? 0;
      const positiveRate = opportunities > 0 ? (pos / opportunities).toFixed(3) : '0.000';
      const negativeRate = opportunities > 0 ? (neg / opportunities).toFixed(3) : '0.000';
      
      return {
        face: c.face,
        family: c.family,
        rawNI: c.rawNI,
        NI: c.NI.toFixed(3),
        SI: c.SI.toFixed(3),
        II: c.II,
        score: c.score.toFixed(3),
        opportunities,
        positiveRate,
        negativeRate,
        votes: `${pos}+/${neg}-`
      };
    }));

    // Sort by score with proper tie-breaking
    const sortedCandidates = finalCandidates.sort((a, b) => {
      // Primary: highest score
      if (Math.abs(a.score - b.score) > 1e-9) {
        return b.score - a.score;
      }
      // Tie-breaker 1: higher NI (more clean wins for the face)
      if (a.NI !== b.NI) {
        return b.NI - a.NI;
      }
      // Tie-breaker 2: higher SI (more stable family)
      if (Math.abs(a.SI - b.SI) > 1e-9) {
        return b.SI - a.SI;
      }
      // Tie-breaker 3: lower II (less instability)
      return a.II - b.II;
    });

    const secondary = sortedCandidates[0];
    
    console.log('🎯 SIF Face Scores Ranking:', sortedCandidates.map(c => ({
      face: c.face,
      family: c.family,
      score: c.score.toFixed(3),
      NI: c.NI,
      SI: c.SI.toFixed(3),
      II: c.II
    })));
    
    console.log('🎯 SIF Selected Secondary:', {
      secondaryFace: secondary.face,
      secondaryFamily: secondary.family,
      score: secondary.score.toFixed(3)
    });

    // Determine badge based on secondary family stability
    const secondaryII = secondary.II;
    const secondarySI = secondary.SI;
    
    // Compare prizes using full keys
    const fullSecondary = `${secondary.family}:${secondary.face}`; // "Control:Rebel"
    const matchesPrize = fullSecondary === actualPrizeFace; // prizeFace stored as "Family:Face"
    
    console.log('🎯 SIF Badge Calculation:', {
      fullSecondary,
      prizeFace: actualPrizeFace,
      secondaryII,
      secondarySI: secondarySI.toFixed(3),
      matchesPrize,
      comparison: `"${fullSecondary}" === "${actualPrizeFace}"`
    });
    
    let badge: 'Aligned' | 'Installed from outside' | 'Not yet aligned';
    if (matchesPrize) {
      badge = 'Aligned';
      console.log('🎯 SIF Badge: Aligned (matches prize face)');
    } else if (secondaryII >= 2 || secondarySI < 0.5) {
      badge = 'Installed from outside';
      console.log('🎯 SIF Badge: Installed from outside (II >= 2 or SI < 0.5)');
    } else {
      badge = 'Not yet aligned';
      console.log('🎯 SIF Badge: Not yet aligned (default)');
    }

    // Build context with friction counts
    const friction: Record<string, number> = {};
    Object.keys(this.counters.famF).forEach(family => {
      if (this.counters.famF[family] > 0) {
        friction[family] = this.counters.famF[family];
      }
    });

    const result = {
      primary: {
        family: primaryFamily,
        face: primaryFace
      },
      secondary: {
        family: secondary.family,
        face: secondary.face
      },
      prize: actualPrizeFace,
      badge,
      context: {
        friction
      }
    };
    
    console.log('🎯 SIF FINAL RESULT:', result);
    console.log('🎯 SIF Friction Points:', friction);
    
    return result;
  }

  /**
   * Get current counters (for debugging)
   */
  getCounters(): SIFCounters {
    return { ...this.counters };
  }

  /**
   * Reset all counters
   */
  reset(): void {
    this.initializeCounters();
  }
}
